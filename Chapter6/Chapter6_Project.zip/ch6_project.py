"""
ch6_project.py: implementing project
    - Author: Vishnu Vijay
    - Created: 7/7/22
"""

import time
import numpy as np
from autopilot import Autopilot
import matplotlib.pyplot as plt

from mav import MAV
from mav_dynamics import MAV_Dynamics
from trim import compute_trim
from compute_models import compute_model
from wind_simulation import WindSimulation
from signals import Signals

from mav_state import MAV_State
from delta_state import Delta_State
from autopilot_cmds import AutopilotCmds


# Create instance of MAV_Dynamics
Ts = 0.01
mav_dynamics = MAV_Dynamics(time_step=Ts) # time step in seconds
mav_state = mav_dynamics.mav_state
# Create instance of MAV object using MAV_State object
fullscreen = False
this_mav = MAV(mav_state, fullscreen)
# Create instance of wind simulation
wind_sim = WindSimulation(Ts)
# Create instance of autopilor
autopilot = Autopilot(Ts)
# Autopilot message
commands = AutopilotCmds()
Va_command = Signals(dc_offset=25.0,
                     amplitude=3.0,
                     start_time=2.0,
                     frequency=0.01)
altitude_command = Signals(dc_offset=0.0,
                           amplitude=10.0,
                           start_time=0.0,
                           frequency=0.02)
course_command = Signals(dc_offset=np.radians(0),
                         amplitude=np.radians(45),
                         start_time=5.0,
                         frequency=0.015)


# Find trim state
Va = 25
gamma_deg = 0
gamma_rad = gamma_deg * np.pi/180
trim_state, trim_input = compute_trim(mav_dynamics, Va, gamma_rad)
mav_dynamics.internal_state = trim_state
delta_trim = trim_input
delta_trim.print()

# Compute state space model linearized about trim
compute_model(mav_dynamics, trim_state, trim_input)


# Run Simulation
curr_time = 0
end_time = 10 # seconds
view_sim = True
sim_real_time = False
display_graphs = True

time_of_last_throttle = 0.

extra_elem = 1

if (display_graphs):
    time_arr = np.zeros(int(end_time / Ts) + extra_elem)
    alt_history = np.zeros(int(end_time / Ts) + extra_elem)
    phi_history = np.zeros(int(end_time / Ts) + extra_elem)
    theta_history = np.zeros(int(end_time / Ts) + extra_elem)
    alpha_history = np.zeros(int(end_time / Ts) + extra_elem)
    psi_history = np.zeros(int(end_time / Ts) + extra_elem)
    d_e_history = np.zeros(int(end_time / Ts) + extra_elem)
    d_a_history = np.zeros(int(end_time / Ts) + extra_elem)
    d_r_history = np.zeros(int(end_time / Ts) + extra_elem)
    d_t_history = np.zeros(int(end_time / Ts) + extra_elem)
    ind = 0

while (curr_time <= end_time) and (view_sim):
    step_start = time.time()
    print("\nTime: " + str(round(curr_time, 2)) + " ", end=" -> \n")

    # autopilot commands
    commands.airspeed_command = 25 #Va_command.square(curr_time)
    commands.course_command = 0 # course_command.square(curr_time)
    commands.altitude_command = 0 # altitude_command.square(curr_time)
    
    # autopilot
    estimated_state = mav_dynamics.mav_state #this is the actual mav state
    quat_orientation = mav_dynamics.internal_state[6:10] #passing in quaternion representation too
    delta, commanded_state = autopilot.update(commands, estimated_state, quat_orientation)
    
    # wind sim
    wind_steady_gust = np.zeros((6,1)) # wind_sim.update()

    # Update MAV dynamic state
    mav_dynamics.iterate(delta, wind_steady_gust)
    if delta.throttle_level > 0:
        time_of_last_throttle = curr_time

    # Update MAV mesh for viewing
    this_mav.set_mav_state(mav_dynamics.mav_state)
    this_mav.update_mav_state()
    this_mav.update_render()
    
    # DEBUGGING - Print Vehicle's state
    if (display_graphs):
        time_arr[ind] = curr_time
        alt_history[ind] = estimated_state.altitude
        phi_history[ind] = estimated_state.phi * 180 / np.pi
        theta_history[ind] = estimated_state.theta * 180 / np.pi
        alpha_history[ind] = estimated_state.alpha * 180 / np.pi
        psi_history[ind] = estimated_state.psi * 180 / np.pi

        d_e_history[ind] = delta.elevator_deflection
        d_a_history[ind] = delta.aileron_deflection
        d_r_history[ind] = delta.rudder_deflection
        d_t_history[ind] = delta.throttle_level


    #mav_dynamics.mav_state.print()
    #commands.print()
    delta.print()
    #print("Wind: ", mav_dynamics.wind_i.T)
    #print("COMMANDED STATE:", end=" -> ")
    #commanded_state.print()


    # Update time
    step_end = time.time()
    if ((sim_real_time) and ((step_end - step_start) < mav_dynamics.time_step)):
        time.sleep(step_end - step_start)
    curr_time += Ts
    ind += 1
    

print("\nTIME OF LAST THROTTLE: ", round(time_of_last_throttle, 2))


if (display_graphs):
    fig, axes = plt.subplots(2, 4)
    
    axes[0,0].plot(time_arr, alt_history)
    axes[0,0].set_title("ALTITUDE")

    axes[0,1].plot(time_arr, theta_history)
    axes[0,1].set_title("THETA")

    axes[1,0].plot(time_arr, phi_history)
    axes[1,0].set_title("PHI")

    axes[1,1].plot(time_arr, psi_history)
    axes[1,1].set_title("PSI")

    axes[0,2].plot(time_arr, d_e_history)
    axes[0,2].set_title("ELEVATOR")

    axes[1,2].plot(time_arr, d_a_history)
    axes[1,2].set_title("AILERON")

    axes[0,3].plot(time_arr, d_t_history)
    axes[0,3].set_title("THROTTLE")

    axes[1,3].plot(time_arr, d_r_history)
    axes[1,3].set_title("RUDDER")

    plt.show()